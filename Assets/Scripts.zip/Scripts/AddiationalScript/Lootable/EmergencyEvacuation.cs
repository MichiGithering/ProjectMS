using UnityEngine;
using UnityEngine.InputSystem;

public class EmergencyEvacuation : MonoBehaviour
{
    private ProjectMSInputAction playerInputActions;

    public void Awake()
    {
        playerInputActions = new ProjectMSInputAction();
    }

    public void OnEnable()
    {
        playerInputActions.Enable();
        playerInputActions.PlayerControl.EmerEvac.started += OnEvacStarted;
        playerInputActions.PlayerControl.EmerEvac.performed += OnEvacPerformed;
        playerInputActions.PlayerControl.EmerEvac.canceled += OnEvacCanceled;
    }

    public void OnDisable()
    {
        if (playerInputActions != null)
        {
            playerInputActions.Disable();
            playerInputActions.PlayerControl.EmerEvac.started -= OnEvacStarted;
            playerInputActions.PlayerControl.EmerEvac.performed -= OnEvacPerformed;
            playerInputActions.PlayerControl.EmerEvac.canceled -= OnEvacCanceled;
        }
    }

    private void OnEvacStarted(InputAction.CallbackContext context)
    {
        Debug.Log("Evacuation started... hold it!");
    }

    private void OnEvacPerformed(InputAction.CallbackContext context)
    {
        Debug.Log("Evacuation successful! Blasting off!");

        if (GameManager.Instance != null)
        {
            GameManager.Instance.GameOver(0);
        }
    }

    private void OnEvacCanceled(InputAction.CallbackContext context)
    {
        Debug.Log("Evacuation canceled or released.");
    }
}