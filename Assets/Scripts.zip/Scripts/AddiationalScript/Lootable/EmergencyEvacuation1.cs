using UnityEngine;
using UnityEngine.InputSystem;

public class BoosterThruster : MonoBehaviour
{
    private ProjectMSInputAction playerInputActions;

    public void Awake()
    {
        playerInputActions = new ProjectMSInputAction();
    }

    public void OnEnable()
    {
        playerInputActions.Enable();
        playerInputActions.PlayerControl.EmerEvac.started += OnThrusterStarted;
    }

    public void OnDisable()
    {
        if (playerInputActions != null)
        {
            playerInputActions.Disable();
            playerInputActions.PlayerControl.EmerEvac.started -= OnThrusterStarted;
        }
    }

    private void OnThrusterStarted(InputAction.CallbackContext context)
    {

    }

}