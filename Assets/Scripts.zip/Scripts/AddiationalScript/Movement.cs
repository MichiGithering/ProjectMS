using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Movement : MonoBehaviour
{
    private Rigidbody2D rb;

    [Header("Movement Settings")]
    public float moveSpeed = 100f;
    public float acceleration = 30f;
    public float deceleration = 35f;

    [Header("Input Smoothing")]
    [Tooltip("How quickly input responds. Higher = snappier, Lower = floatier. Keyboard feels best at 15+, Joystick at 6-10.")]
    [SerializeField] private float inputSmoothing = 8f;

    [Header("Fuel Handling")]
    private Spaceship spaceship;
    private float RemainFuel;
    private bool HasFuel = true;

    private Vector2 moveInput;    // Raw input from Player.cs
    public Vector2 smoothedInput; // Interpolated input used for movement

    // -------------------------------------------------------------------------
    // Initialization
    // -------------------------------------------------------------------------

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f;

        EntityConfig entityConfig = GetComponent<Entity>()?._entityConfig;
        if (entityConfig != null)
        {
            moveSpeed = entityConfig.MaxSpeed;
        }

        spaceship = GetComponent<Spaceship>();
    }


    private void FixedUpdate()
    {
        // Smoothly interpolate raw input toward target each physics step
        smoothedInput = Vector2.Lerp(smoothedInput, moveInput, inputSmoothing * Time.fixedDeltaTime);

        if (spaceship != null)
        {
            RemainFuel = spaceship.Fuel;
            HasFuel = RemainFuel > 0;
            if (HasFuel)
                ApplyMovement();
        }
        else
        {
            ApplyMovement();
        }
    }

    public void MoveHorizontal(float input) => moveInput.x = input;
    public void MoveVertical(float input) => moveInput.y = input;


    public void ApplyMovement()
    {
        // 1. Use smoothedInput so direction changes blend gradually
        Vector2 targetVelocity = smoothedInput.normalized * moveSpeed;

        // 2. Determine if speeding up or slowing down
        float speedChange = smoothedInput.magnitude > 0.01f ? acceleration : deceleration;

        // 3. Smoothly move current velocity toward target
        float newVelX = Mathf.MoveTowards(rb.linearVelocity.x, targetVelocity.x, speedChange * Time.fixedDeltaTime);
        float newVelY = Mathf.MoveTowards(rb.linearVelocity.y, targetVelocity.y, speedChange * Time.fixedDeltaTime);

        // 4. Apply with speed cap
        Vector2 newVelocity = new Vector2(newVelX, newVelY);
        if (newVelocity.magnitude > moveSpeed)
            newVelocity = newVelocity.normalized * moveSpeed;

        rb.linearVelocity = newVelocity;
    }

    public void ApplyBoosterThruster()
    {
        if (spaceship != null && spaceship.Fuel >= 20f)
        {
            Vector2 boostDirection = smoothedInput.normalized;
            if (boostDirection.magnitude < 0.1f)
            {
                boostDirection = transform.up; // Default forward direction
            }
            float boostAmount = 200f; // Adjust as needed
            rb.AddForce(boostDirection * boostAmount, ForceMode2D.Impulse);
            spaceship.ConsumeFuel(20f);
        }
    }
}