using JetBrains.Annotations;
using System.Xml.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;
using System.Collections;

public class Player : Spaceship
{
    [Header("Player Specific")]
    [SerializeField] private ProjectMSInputAction playerInputActions;
    public Movement movementScript;
    public int HP;

    public static Player Instance { get; private set; }

    private bool isThrusting = false;

    // Initialization
    protected override void Awake()
    {
        base.Awake();
        playerInputActions = new ProjectMSInputAction();

        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        if (movementScript == null)
        {
            movementScript = GetComponent<Movement>();
            if (movementScript == null)
            {
                movementScript = gameObject.AddComponent<Movement>();
            }
        }
        ApplyUpgrades();
        InitializedVariance();
    }
    public override void Start()
    {
        base.Start();
    }
    public override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);
    }

    private void InitializedVariance()
    {
        Fuel = MaxFuel;
        Missiles = MaxMissiles;

        if (GameManager.Instance != null)
        {
            GameManager.Instance.MaxFuel = MaxFuel;
            GameManager.Instance.Fuel = Fuel;  
            GameManager.Instance.MaxMissiles = MaxMissiles;
            GameManager.Instance.Missiles = Missiles;
        }
    }
    public void UpdateVariance()
    {
        Fuel = Mathf.Clamp(Fuel, 0f, MaxFuel);
        Missiles = Mathf.Clamp(Missiles, 0, MaxMissiles);

        if (GameManager.Instance != null)
        {
            GameManager.Instance.Fuel = Fuel;
            GameManager.Instance.Missiles = Missiles;

        }
    }

    public override void FixedUpdate()
    {
        base.FixedUpdate();

        UpdateVariance();
        RotationOnMove();

        if (Fuel <= 0)
        {
            movementScript.enabled = false;
        }

        if (activeThruster != null)
        {
            if (isThrusting && Fuel > 0)
            {
                if (!activeThruster.isEmitting)
                {
                    activeThruster.Play();
                }
            }
            else
            {
                if (activeThruster.isEmitting)
                {
                    activeThruster.Stop();
                }
            }
        }
    }

    private void RotationOnMove()
    {
        float rotationSpeed = 450f;

        // Use smoothed input direction � stops when input stops, no velocity drift
        Vector2 direction = movementScript.smoothedInput;

        if (direction.magnitude > 0.1f)
        {
            float targetAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion targetRotation = Quaternion.Euler(0, 0, targetAngle - 90f);

            transform.rotation = Quaternion.RotateTowards(
                transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }
    }

    // Input Handling
    private void OnEnable()
    {
        playerInputActions.Enable();

        playerInputActions.PlayerControl.Movement.performed += OnMovementPerformed;
        playerInputActions.PlayerControl.Movement.canceled += OnMovementCanceled;

        playerInputActions.PlayerControl.LaunchMissile.performed += context => LaunchMissile();
    }
    private void OnDisable()
    {
        playerInputActions.PlayerControl.Movement.performed -= OnMovementPerformed;
        playerInputActions.PlayerControl.Movement.canceled -= OnMovementCanceled;

        playerInputActions.Disable();
    }
    private void OnMovementPerformed(InputAction.CallbackContext context)
    {
        Vector2 input = context.ReadValue<Vector2>();
        movementScript.MoveHorizontal(input.x);
        movementScript.MoveVertical(input.y);
        isThrusting = true;
    }
    private void OnMovementCanceled(InputAction.CallbackContext context)
    {
        movementScript.MoveHorizontal(0f);
        movementScript.MoveVertical(0f);
        isThrusting = false;
    }
    protected override void LaunchMissile()
    {
        if (GameManager.Instance.currentState != GameManager.GameState.Playing) 
            return;

        Debug.Log("Player is launching a missile!");
        base.LaunchMissile();
    }
    private void ApplyUpgrades()
    {
        if (UpgradeManager.Instance == null)
        {
            return;
        }
        UpgradeManager.UpgradeProfileData upgrades = UpgradeManager.Instance.LoadUpgrades();

        // 1. Calculate the new Max Stats
        MaxHP += (upgrades.HealthLevel - 1);
        MaxMovementSpeed += (upgrades.SpeedLevel - 1) * 0.5f;
        MaxFuel += (upgrades.FuelLevel - 1) * (5f + upgrades.FuelLevel);
        MaxMissiles += (upgrades.MissileLevel - 1) * 1;

        // 2. FILL THE TANKS! (Set current resources to match the new max)
        Fuel = MaxFuel;
        Missiles = MaxMissiles;

        // 3. Apply to other scripts
        if (movementScript != null)
        {
            movementScript.moveSpeed = MaxMovementSpeed;
        }

        // 4. Sync EVERYTHING to the GameManager
        if (GameManager.Instance != null)
        {
            GameManager.Instance.MaxFuel = MaxFuel;
            GameManager.Instance.MaxMissiles = MaxMissiles;

            // Sync the filled tanks!
            GameManager.Instance.Fuel = Fuel;
            GameManager.Instance.Missiles = Missiles;
        }
    }

    protected override void OnDeath()
    {
        GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<Collider2D>().enabled = false;
        movementScript.enabled = false;

        if (activeThruster != null)
        {
            activeThruster.Stop();
        }

        if (ImpactEffect != null)
        {
            Instantiate(ImpactEffect, transform.position, Quaternion.identity);
        }

        StartCoroutine(WaitAndGameOver());
    }

    private IEnumerator WaitAndGameOver()
    {
        yield return new WaitForSeconds(3f);

        GameManager.Instance.GameOver(2);

        Destroy(gameObject);
    }

}

