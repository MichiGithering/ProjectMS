using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI; // Needed for the Image component

public class SceneTransition : MonoBehaviour
{
    public static SceneTransition Instance { get; private set; }

    [Header("Transition Settings")]
    [SerializeField] private Image fadeImage;
    [SerializeField] private float fadeSpeed = 1.5f;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        
        // Ensure the screen starts clear if the image is accidentally left on
        if (fadeImage != null)
        {
            fadeImage.gameObject.SetActive(true);
            fadeImage.color = new Color(0, 0, 0, 100); 
            fadeImage.raycastTarget = false; // Allow clicks initially


        }
    }
    private void Start()
    {
               StartCoroutine(FadeIn());
    }
    private IEnumerator FadeIn()
    {
        if (fadeImage == null)
        {
            yield break;
        }

        yield return new WaitForSecondsRealtime(0.2f);

        float alpha = 1f;
        while (alpha > 0f)
        {
            alpha -= Time.unscaledDeltaTime * fadeSpeed;
            fadeImage.color = new Color(0, 0, 0, alpha);
            yield return null;
        }
        fadeImage.color = new Color(0, 0, 0, 0);
    }
    public void TransitionToScene(string sceneName)
    {
        StartCoroutine(FadeOutAndLoad(sceneName));
    }

    private IEnumerator FadeOutAndLoad(string sceneName)
    {
        if (fadeImage == null)
        {
            Debug.LogWarning("No fade image assigned! Loading scene instantly.");
            SceneManager.LoadScene(sceneName);
            yield break;
        }

        // Block UI clicks during the fade
        fadeImage.raycastTarget = true;

        float alpha = 0f;
        while (alpha < 1f)
        {
            alpha += Time.unscaledDeltaTime * fadeSpeed;
            fadeImage.color = new Color(0, 0, 0, alpha);
            yield return null;
        }

        yield return new WaitForSecondsRealtime(0.5f);

        // The screen is fully black, now it's safe to load the scene
        SceneManager.LoadScene(sceneName);
    }
}