using TMPro;
using UnityEngine;

public class UpgradeAncInventoryManager : MonoBehaviour

{
    [SerializeField] private Canvas UpgradeCanvas;
    [SerializeField] private Canvas CargoCanvas;
    [SerializeField] private TextMeshProUGUI UpHpcost;
    [SerializeField] private TextMeshProUGUI UpSpcost;
    [SerializeField] private TextMeshProUGUI UpFtcost;
    [SerializeField] private TextMeshProUGUI UpMscost;

    public static UpgradeAncInventoryManager Instance { get; private set; }

    private ProjectMSInputAction playerInputActions;
    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        playerInputActions = new ProjectMSInputAction();
        playerInputActions.GameControl.MenuUpgrade.performed += ctx => ToggleUpgrade();
        playerInputActions.GameControl.MenuCargo.performed += ctx => ToggleCargo();
    }

    void Start()
    {
        if (UpgradeCanvas != null) UpgradeCanvas.enabled = false;
        if (CargoCanvas != null) CargoCanvas.enabled = false;
        UpdateUpgradeCosts();
    }
    private void OnEnable()
    {
        playerInputActions.Enable();
    }

    private void OnDisable()
    {
        playerInputActions.Disable();
    }
    private void ToggleUpgrade()
    {
        if (CargoCanvas != null)
            CargoCanvas.enabled = false;

        if (UpgradeCanvas != null)
        {
            UpgradeCanvas.enabled = !UpgradeCanvas.enabled;
        }
    }
    private void ToggleCargo()
    {
        if (UpgradeCanvas != null)
            UpgradeCanvas.enabled = false;

        if (CargoCanvas != null)
        {
            CargoCanvas.enabled = !CargoCanvas.enabled;
        }
    }

    public void UpdateUpgradeCosts()
    {
        // 1. Get the player's current upgrade levels from the Mechanic
        UpgradeManager.UpgradeProfileData profile = UpgradeManager.Instance.LoadUpgrades();
        SaveScoreManager.PlayerProfileData RPprofile = SaveScoreManager.Instance.LoadGame();

        // 2. Calculate the cost for the NEXT level (Adjust these base numbers however you want!)
        int hpCost = 20 + ((profile.HealthLevel-1) * (3 + profile.HealthLevel));
        int spCost = 20 + ((profile.SpeedLevel-1) * (5 + profile.SpeedLevel));
        int ftCost = 40 + ((profile.FuelLevel-1) * (5 + profile.FuelLevel));
        int msCost = 30 + ((profile.MissileLevel-1) * (7 + profile.MissileLevel));

        // 3. Update the Text on the screen (Add " RP" so the player knows the currency)
        if (UpHpcost != null) UpHpcost.text = hpCost.ToString();
        if (UpSpcost != null) UpSpcost.text = spCost.ToString();
        if (UpFtcost != null) UpFtcost.text = ftCost.ToString();
        if (UpMscost != null) UpMscost.text = msCost.ToString();

        RPOnMenuUpdate.Instance.UpdateRP(RPprofile.TotalResearchPoints);
    }
}
