using UnityEngine;
using System.Collections;
public class Planet : Objects
{
    [Header("Planet")]
    [SerializeField] public RewardConfig _rewardConfig;
    private SpriteRenderer spriteRenderer;
    [SerializeField] public bool randomizeColor = true;

    [Header("Reward")]
    public bool HasReward = true;
    private float ReFuel;
    private int ReMissile;

    protected override void Awake()
    {
        base.Awake();

        if (_rewardConfig == null)
        {
            Debug.LogWarning($"Planet {gameObject.name} is missing a RewardConfig!");
            _rewardConfig = ScriptableObject.CreateInstance<RewardConfig>();
        }

        if (!Mirage)
        {
            HasReward = true;
            ReFuel = _rewardConfig.ReFuel;
            ReMissile = _rewardConfig.ReMissile;
        }
        else
        {
            HasReward = false;
        }
    }

    public override void Start()
    {
        base.Start();
        spriteRenderer = GetComponent<SpriteRenderer>();
        
        if (spriteRenderer != null && randomizeColor)
        {
            Color randomColor = Random.ColorHSV(0f, 1f, 0.5f, 1f, 0.5f, 1f);
            spriteRenderer.color = randomColor; 
            _originalColor = randomColor;
        }
    }
    public override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

    }

    public void GetReward(Player playerScript)
    {
        if (HasReward && !Mirage)
        {
            if(_rewardConfig.chanceToBlank > 0f)
            {
                float roll = Random.Range(0f, 1f);
                if (roll < _rewardConfig.chanceToBlank)
                {
                    ReFuel = 0f;
                    ReMissile = 0;
                }
            }
            playerScript.Fuel += ReFuel;
            playerScript.Missiles += ReMissile;
            // Turn off the collider so they can fly through the empty husk
            GetComponent<Collider2D>().enabled = false;
            HasReward = false;

            Debug.Log($"Collected {ReFuel} Fuel and {ReMissile} Missiles from Planet!");

            Color emptyColor = new Color(0.5f, 0.5f, 0.5f, 1f);
            _originalColor = emptyColor;

            StartCoroutine(FadeToGrey(emptyColor, 1f));

            GameManager.Instance.AddResearchPoints(_rewardConfig.RewardPoints);
        }
    }

    // The Coroutine that handles the smooth visual transition
    private IEnumerator FadeToGrey(Color targetColor, float fadeDuration)
    {
        SpriteRenderer sr = GetComponent<SpriteRenderer>();

        if (sr != null)
        {
            Color startColor = sr.color;
            float elapsed = 0f;

            while (elapsed < fadeDuration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / fadeDuration;

                sr.color = Color.Lerp(startColor, targetColor, t);

                yield return null; 
            }

            sr.color = targetColor;
        }
    }
}