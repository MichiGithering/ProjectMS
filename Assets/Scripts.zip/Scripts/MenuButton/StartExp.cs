using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class StartExp : MonoBehaviour
{
    private ProjectMSInputAction playerInputActions;

    private void Awake()
    {
        playerInputActions = new ProjectMSInputAction();
    }
    private void OnEnable()
    {
        playerInputActions.Enable();

        playerInputActions.GameControl.MenuExpedition.performed += OnStartExpeditionPerformed;
    }

    private void OnDisable()
    {
        playerInputActions.GameControl.MenuExpedition.performed -= OnStartExpeditionPerformed;

        playerInputActions.Disable();
    }

    private void OnStartExpeditionPerformed(InputAction.CallbackContext context)
    {
        if(SceneTransition.Instance != null)
        {
            SceneTransition.Instance.TransitionToScene("MainGameplayScene");
        }
        else
        {
            SceneManager.LoadScene("MainGameplayScene");
        }
    }
}